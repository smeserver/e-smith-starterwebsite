#!/usr/bin/perl -w 

#----------------------------------------------------------------------
# $Id: starterwebsite.pm,v 1.2 2002/04/04 05:16:28 gordonr Exp $
#----------------------------------------------------------------------
# copyright (C) 2002 Mitel Networks Corporation
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 		
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 		
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
# 
# Technical support for this program is available from Mitel Networks 
# Please visit our web site www.e-smith.com for details.
#----------------------------------------------------------------------
package    esmith::FormMagick::Panel::starterwebsite;

use strict;

use esmith::FormMagick;
use esmith::util;
use esmith::ConfigDB;
use File::Basename;
use Exporter;
use Carp;

our @ISA = qw(esmith::FormMagick Exporter);

our @EXPORT = qw( change_settings print_homepage_url print_message);

our $VERSION = sprintf '%d.%03d', q$Revision: 1.2 $ =~ /: (\d+).(\d+)/;
our $db = esmith::ConfigDB->open;

# {{{ header

=pod 

=head1 NAME

esmith::FormMagick::Panels::starterwebsite - useful panel functions

=head1 SYNOPSIS

    use esmith::FormMagick::Panels::starterwebsite;

    my $panel = esmith::FormMagick::Panel::starterwebsite->new();
    $panel->display();

=head1 DESCRIPTION

=cut

# {{{ new

=head2 new();

Exactly as for esmith::FormMagick

=begin testing


use_ok('esmith::FormMagick::Panel::starterwebsite');
use vars qw($panel);
ok($panel = esmith::FormMagick::Panel::starterwebsite->new(), "Create panel object");
isa_ok($panel, 'esmith::FormMagick::Panel::starterwebsite');

=end testing

=cut



sub new {
    shift;
    my $self = esmith::FormMagick->new();
    $self->{calling_package} = (caller)[0];
    bless $self;
    return $self;
}

# }}}

=head2 print_message

   Prints an arbitrary message in the context of the form

=cut


sub print_message {
    my ($fm, $word) = @_;
    $word = $fm->localise($word);
    print qq(<tr><td colspan=2>$word</td></tr>);
    return undef;

}



=head2 print_homepage_url

    returns the url for this e-smith server\'s default website as an href

=cut


sub print_homepage_url {
    my $fm = shift;
    my $url = "http://www.". $db->get('DomainName')->value();
    my $href = "<a href=\"$url\">$url</a>";
    return (print_message($fm, $href))
}


=head1 ACTION

=head2 change_settings

Build the new default web page

=cut



sub change_settings {
  my ($fm) = @_;
  
  my $q = $fm->{'cgi'};

    if (! open (WR, ">/home/e-smith/files/primary/html/index.htm"))
    {
      $fm->{cgi}->param( -name  => 'initial_message', -value => 'OPEN_INDEX_FAIL');
      $fm->{cgi}->param( -name => 'wherenext', -value => 'Done' );
      # Tell the user something bad has happened
        return;
    }

    my $companyName = $q->param ('companyName');
    my $header1     = $q->param ('header1');
    my $text1       = $q->param ('text1');
    my $header2     = $q->param ('header2');
    my $text2       = $q->param ('text2');
    
    # make sure company name is not blank
    if ($companyName =~ /^\s*$/s) {
	$companyName = "&nbsp;"
    }

    print WR "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 3.2 Final//EN\">\n";
    print WR "\n";
    print WR "<HTML>\n";
    print WR "\n";
    print WR "<HEAD>\n";
    print WR "<TITLE>$companyName</TITLE>\n";
    print WR "<META HTTP-EQUIV=\"Expires\" CONTENT=\"0\">\n";
    print WR "</HEAD>\n";
    print WR "\n";
    print WR "<BODY BGCOLOR=\"#FFFFFF\" MARGINWIDTH=\"0\" MARGINHEIGHT=\"0\" LEFTMARGIN=\"0\" TOPMARGIN=\"0\">\n";
    print WR "\n";
    print WR "<TABLE BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"10\" WIDTH=\"100%\">\n";
    print WR "\n";
    print WR "<TR>\n";
    print WR "<TD BGCOLOR=\"#290099\" COLSPAN=\"2\"><FONT COLOR=\"#F7E0B5\"><H1>$companyName</H1></FONT></TD>\n";
    print WR "</TR>\n";
    print WR "\n";
    print WR "<TR>\n";
    print WR "<TD BGCOLOR=\"#F7E0B5\" WIDTH=\"15%\">&nbsp;</TD>\n";
    print WR "<TD BGCOLOR=\"#FFFFFF\" WIDTH=\"85%\">\n";
    print WR "\n";

    if ($header1 !~ /^\s*$/s)
    {
	print WR "<FONT COLOR=\"#000000\"><H2>$header1</H2></FONT>\n";
	print WR "\n";
    }

    if ($text1 !~ /^\s*$/s)
    {
	$text1 =~ s/^\s*(.*?)\s*$/$1/s;
	$text1 =~ s/\r\s*\r/<P>/sg;

	print WR "<FONT COLOR=\"#290099\">\n";
	print WR "<P>\n";
	print WR "$text1\n";
	print WR "</P>\n";
	print WR "</FONT>\n";
	print WR "\n";
    }

    if ($header2 !~ /^\s*$/s)
    {
	print WR "<FONT COLOR=\"#000000\"><H2>$header2</H2></FONT>\n";
	print WR "\n";
    }

    if ($text2 !~ /^\s*$/s)
    {
	$text2 =~ s/^\s*(.*?)\s*$/$1/s;
	$text2 =~ s/\r\s*\r/<P>/sg;

	print WR "<FONT COLOR=\"#290099\">\n";
	print WR "<P>\n";
	print WR "$text2\n";
	print WR "</P>\n";
	print WR "</FONT>\n";
	print WR "\n";
    }

    print WR "\n";
    print WR "</TD>\n";
    print WR "</TR>\n";
    print WR "</TABLE>\n";
    print WR "</BODY>\n";
    print WR "</HTML>\n";

    close WR;

    esmith::util::chownFile("admin", "shared",
	"/home/e-smith/files/primary/html/index.htm");
    chmod 0640, "/home/e-smith/files/primary/html/index.htm";


  #$fm->{cgi}->param( -name  => 'initial_message', -value => 'CHANGE_SUCCEEDED');
    $fm->{cgi}->param( -name => 'wherenext', -value => 'Done' );
}


1;
